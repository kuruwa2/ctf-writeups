#!/usr/bin/env python3

from Crypto.Util.number import *
from secret import flag

def encrypt(msg):
    l = len(msg) // 2
    m0, m1 = bytes_to_long(msg[:l]), bytes_to_long(msg[l:])
    p = m1 << 1
    while not isPrime(p+1):
        p *= getPrime(21)
    q = ((p * 67) + 67) ^ 67
    while not isPrime(q):
        q *= 67
        q += 67
        q ^= 67
        if len(bin(q)) > 2048:
            break
    n = p * q
    while True:
        y = getRandomRange(1, n)
        if pow(y, m1, n) != 1:
            break
    while True:
        u = getRandomRange(1, n)
        if GCD(u, n) == 1:
            break
    c = pow(y, m0, n) * pow(u, (p - 1) * (q - 1) // m1, n)
    return n, y, c
    
if __name__ == '__main__':
    n, y, c = encrypt(flag)
    print('n =', n)
    print('y =', y)
    print('c =', c)
