#!/bin/bash
cd /home/RSA
timeout 60 ./chall.py
